# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from .azureml_request_header_provider import AzureMLRequestHeaderProvider

__all__ = ["AzureMLRequestHeaderProvider"]
