# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from mldesigner._version import VERSION

USER_AGENT = "{}/{}".format("mldesigner", VERSION)
