# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
import os
from typing import Optional, Dict, TypeVar, Union, Tuple
from pathlib import Path
from datetime import datetime, timedelta
import uuid

from azure.storage.blob import generate_blob_sas, BlobSasPermissions
from azure.ml._operations import DatastoreOperations
from azure.ml._utils._storage_utils import get_storage_client, STORAGE_ACCOUNT_URLS
from azure.ml.entities import Environment
from azure.ml.entities._assets._artifacts.artifact import Artifact, ArtifactStorageInfo
from azure.ml.entities._datastore.credentials import AccountKeyCredentials
from azure.ml._utils._arm_id_utils import (
    get_datastore_arm_id,
    get_resource_name_from_arm_id,
    remove_aml_prefix,
    is_ARM_id_for_resource,
)
from azure.ml._utils._asset_utils import (
    _validate_path,
    get_object_hash,
    get_ignore_file,
    IgnoreFile,
    _build_metadata_dict,
)
from azure.ml._utils._storage_utils import get_artifact_path_from_blob_url, AzureMLDatastorePathUri
from azure.ml._dependent_operations import OperationScope
from azure.ml._restclient.v2021_10_01.models import (
    DatastoreType,
)
from azure.ml._utils.utils import is_url, is_mlflow_uri
from azure.ml._utils._arm_id_utils import AMLNamedArmId
from azure.ml._constants import SHORT_URI_FORMAT


module_logger = logging.getLogger(__name__)


def _get_datastore_name(datastore_operation: DatastoreOperations, datastore_name: str):
    datastore_name = datastore_name or datastore_operation.get_default().name
    try:
        datastore_name = get_resource_name_from_arm_id(datastore_name)
    except (ValueError, AttributeError):
        module_logger.debug(f"datastore_name {datastore_name} is not a full arm id. Proceed with a shortened name.\n")
    datastore_name = remove_aml_prefix(datastore_name)
    if is_ARM_id_for_resource(datastore_name):
        datastore_name = get_resource_name_from_arm_id(datastore_name)
    return datastore_name


def get_datastore_info(operations: DatastoreOperations, name: str) -> Dict[str, str]:
    """
    Get datastore account, type, and auth information
    """
    datastore_info = {}
    if name:
        datastore = operations.get(name, include_secrets=True)
    else:
        datastore = operations.get_default(include_secrets=True)

    credentials = datastore.credentials
    datastore_info["storage_type"] = datastore.type
    datastore_info["storage_account"] = datastore.account_name
    datastore_info["container_name"] = str(
        datastore.container_name if datastore.type == DatastoreType.AZURE_BLOB else datastore.file_share_name
    )
    datastore_info["account_url"] = STORAGE_ACCOUNT_URLS[datastore.type].format(datastore.account_name)
    if isinstance(credentials, AccountKeyCredentials):
        datastore_info["credential"] = credentials.account_key
    else:
        try:
            datastore_info["credential"] = credentials.sas_token
        except Exception as e:
            if not hasattr(credentials, "sas_token"):
                datastore_info["credential"] = operations._credential
            else:
                raise e
    return datastore_info


def list_logs_in_datastore(ds_info: Dict[str, str], blob_prefix: str, legacy_log_folder_name: str) -> Dict[str, str]:
    """
    Returns a dictionary of file name to blob uri with SAS token, matching the structure of RunDetials.logFiles

    legacy_log_folder_name: the name of the folder in the datastore that contains the logs
        /azureml-logs/*.txt is the legacy log structure for commandJob and sweepJob
        /logs/azureml/*.txt is the legacy log structure for pipeline parent Job
    """
    # Only support blob storage for azureml log outputs
    if ds_info["storage_type"] != DatastoreType.AZURE_BLOB:
        raise Exception("Can only list logs in blob storage")
    storage_client = get_storage_client(
        credential=ds_info["credential"],
        container_name=ds_info["container_name"],
        storage_account=ds_info["storage_account"],
        storage_type=ds_info["storage_type"],
    )
    blobs = storage_client.list(starts_with=blob_prefix + "/user_logs/")
    # Append legacy log files if present
    blobs.extend(storage_client.list(starts_with=blob_prefix + legacy_log_folder_name))

    log_dict = {}
    for blob_name in blobs:
        sub_name = blob_name.split(blob_prefix + "/")[1]
        token = generate_blob_sas(
            account_name=ds_info["storage_account"],
            container_name=ds_info["container_name"],
            blob_name=blob_name,
            account_key=ds_info["credential"],
            permission=BlobSasPermissions(read=True),
            expiry=datetime.utcnow() + timedelta(minutes=30),
        )

        log_dict[sub_name] = "{}/{}/{}?{}".format(ds_info["account_url"], ds_info["container_name"], blob_name, token)
    return log_dict


def _get_default_datastore_info(datastore_operation):
    return get_datastore_info(datastore_operation, None)


def upload_artifact(
    local_path: str,
    datastore_operation: DatastoreOperations,
    operation_scope: OperationScope,
    datastore_name: Optional[str],
    asset_hash: str = None,
    show_progress: bool = True,
    asset_name: str = None,
    asset_version: str = None,
    ignore_file: IgnoreFile = IgnoreFile(None),
) -> ArtifactStorageInfo:
    """
    Upload local file or directory to datastore
    """
    datastore_name = _get_datastore_name(datastore_operation, datastore_name)
    datastore_info = get_datastore_info(datastore_operation, datastore_name)
    storage_client = get_storage_client(**datastore_info)
    artifact_info = storage_client.upload(
        local_path,
        asset_hash=asset_hash,
        show_progress=show_progress,
        name=asset_name,
        version=asset_version,
        ignore_file=ignore_file,
    )

    artifact = ArtifactStorageInfo(
        name=artifact_info["name"],
        version=artifact_info["version"],
        relative_path=artifact_info["remote path"],
        datastore_arm_id=get_datastore_arm_id(datastore_name, operation_scope),
        container_name=datastore_info["container_name"],
        storage_account_url=datastore_info.get("account_url"),
        indicator_file=artifact_info["indicator file"],
        is_file=Path(local_path).is_file(),
    )
    return artifact


def download_artifact(
    starts_with: Union[str, os.PathLike],
    destination: str,
    datastore_operation: DatastoreOperations,
    datastore_name: Optional[str],
    datastore_info: Dict = None,
) -> str:
    """
    Download datastore path to local file or directory.

    :param Union[str, os.PathLike] starts_with: Prefix of blobs to download
    :param str destination: Path that files will be written to
    :param DatastoreOperations datastore_operation: Datastore operations
    :param Optional[str] datastore_name: name of datastore
    :param Dict datastore_info: the return value of invoking get_datastore_info
    :return str: Path that files were written to
    """
    starts_with = starts_with.as_posix() if isinstance(starts_with, Path) else starts_with
    datastore_name = _get_datastore_name(datastore_operation, datastore_name)
    if datastore_info is None:
        datastore_info = get_datastore_info(datastore_operation, datastore_name)
    storage_client = get_storage_client(**datastore_info)
    storage_client.download(starts_with=starts_with, destination=destination)
    return destination


def download_artifact_from_blob_url(
    blob_url: str,
    destination: str,
    datastore_operation: DatastoreOperations,
    datastore_name: Optional[str],
) -> str:
    """
    Download datastore blob URL to local file or directory.
    """
    datastore_name = _get_datastore_name(datastore_operation, datastore_name)
    datastore_info = get_datastore_info(datastore_operation, datastore_name)
    starts_with = get_artifact_path_from_blob_url(
        blob_url=str(blob_url), container_name=datastore_info.get("container_name")
    )
    return download_artifact(
        starts_with=starts_with,
        destination=destination,
        datastore_operation=datastore_operation,
        datastore_name=datastore_name,
        datastore_info=datastore_info,
    )


def download_artifact_from_aml_uri(uri: str, destination: str, datastore_operation: DatastoreOperations):
    """Downloads artifact pointed to by URI of the form `azureml://...` to destination

    :param str uri: AzureML uri of artifact to download
    :param str destination: Path to download artifact to
    :param DatastoreOperations datastore_operation: datastore operations
    :return str: Path that files were downloaded to
    """
    parsed_uri = AzureMLDatastorePathUri(uri)
    return download_artifact(
        starts_with=parsed_uri.path,
        destination=destination,
        datastore_operation=datastore_operation,
        datastore_name=parsed_uri.datastore,
    )


def aml_datastore_path_exists(uri: str, datastore_operation: DatastoreOperations, datastore_info: dict = None):
    """Checks whether `uri` of the form "azureml://" points to either a directory or a file

    :param str uri: azure ml datastore uri
    :param DatastoreOperations datastore_operation: Datastore operation
    :param dict datastore_info: return value of get_datastore_info
    """
    parsed_uri = AzureMLDatastorePathUri(uri)
    datastore_info = datastore_info or get_datastore_info(datastore_operation, parsed_uri.datastore)
    return get_storage_client(**datastore_info).exists(parsed_uri.path)


def _upload_to_datastore(
    operation_scope: OperationScope,
    datastore_operation: DatastoreOperations,
    path: Union[str, Path, os.PathLike],
    datastore_name: str = None,
    show_progress: bool = True,
    asset_name: str = None,
    asset_version: str = None,
) -> ArtifactStorageInfo:
    _validate_path(path)
    ignore_file = get_ignore_file(path)
    asset_hash = get_object_hash(path, ignore_file)
    artifact = upload_artifact(
        str(path),
        datastore_operation,
        operation_scope,
        datastore_name,
        show_progress=show_progress,
        asset_hash=asset_hash,
        asset_name=asset_name,
        asset_version=asset_version,
        ignore_file=ignore_file,
    )
    return artifact


def _upload_and_generate_remote_uri(
    operation_scope: OperationScope,
    datastore_operation: DatastoreOperations,
    path: Union[str, Path, os.PathLike],
    datastore_name: str = None,
) -> str:

    # Asset name is required for uploading to a datastore
    asset_name = str(uuid.uuid4())
    artifact_info = _upload_to_datastore(
        operation_scope=operation_scope,
        datastore_operation=datastore_operation,
        path=path,
        datastore_name=datastore_name,
        asset_name=asset_name,
    )

    path = artifact_info.relative_path
    datastore = AMLNamedArmId(artifact_info.datastore_arm_id).asset_name
    return SHORT_URI_FORMAT.format(datastore, path)


def _update_metadata(name, version, indicator_file, datastore_info) -> None:
    storage_client = get_storage_client(**datastore_info)
    container_client = storage_client.container_client
    if indicator_file.startswith(storage_client.container):
        indicator_file = indicator_file.split(storage_client.container)[1]
    blob = container_client.get_blob_client(blob=indicator_file)
    blob.set_blob_metadata(_build_metadata_dict(name=name, version=version))


T = TypeVar("T", bound=Artifact)


def _check_and_upload_path(
    artifact: T,
    asset_operations: Union["DatasetOperations", "DataOperations", "ModelOperations", "CodeOperations"],
    datastore_name: str = None,
) -> Tuple[T, str]:

    indicator_file = None
    if (
        hasattr(artifact, "local_path")
        and artifact.local_path is not None
        or (hasattr(artifact, "path") and not (is_url(artifact.path) or is_mlflow_uri(artifact.path)))
    ):
        path = (
            Path(artifact.path)
            if hasattr(artifact, "path") and artifact.path is not None
            else Path(artifact.local_path)
        )
        if not path.is_absolute():
            path = Path(artifact.base_path, path).resolve()
        uploaded_artifact = _upload_to_datastore(
            asset_operations._operation_scope,
            asset_operations._datastore_operation,
            path,
            datastore_name=datastore_name,
            asset_name=artifact.name,
            asset_version=str(artifact.version),
        )
        indicator_file = uploaded_artifact.indicator_file  # reference to storage contents
        if artifact._is_anonymous:
            artifact.name, artifact.version = uploaded_artifact.name, uploaded_artifact.version
        # Pass all of the upload information to the assets, and they will each construct the URLs that they support
        artifact._update_path(uploaded_artifact)
    return artifact, indicator_file


def _check_and_upload_env_build_context(environment: Environment, operations: "EnvironmentOperations") -> Environment:
    if environment.build and environment.build.path and not is_url(environment.build.path):
        path = Path(environment.build.path)
        if not path.is_absolute():
            path = Path(environment.base_path, path).resolve()
        uploaded_artifact = _upload_to_datastore(
            operations._operation_scope,
            operations._datastore_operation,
            path,
            asset_name=environment.name,
            asset_version=str(environment.version),
        )
        # TODO: Depending on decision trailing "/" needs to stay or not. EMS requires it to be present
        environment.build.path = uploaded_artifact.full_storage_path + "/"

    return environment
