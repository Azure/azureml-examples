# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from marshmallow import fields

from azure.ml._schema.core.schema import PatchedSchemaMeta
from azure.ml._schema.core.fields import StringTransformedEnum
from azure.ml._restclient.v2021_10_01.models import (
    Goal,
)

module_logger = logging.getLogger(__name__)


class SweepObjectiveSchema(metaclass=PatchedSchemaMeta):
    goal = StringTransformedEnum(required=True, allowed_values=[Goal.MINIMIZE, Goal.MAXIMIZE])
    primary_metric = fields.Str(required=True)
