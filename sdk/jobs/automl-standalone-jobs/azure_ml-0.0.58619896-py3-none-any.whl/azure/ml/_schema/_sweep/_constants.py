# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


BASE_ERROR_MESSAGE = "Search space type not one of: "
