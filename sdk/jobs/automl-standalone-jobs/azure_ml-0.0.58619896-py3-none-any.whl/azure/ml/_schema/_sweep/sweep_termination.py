# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from marshmallow import fields, post_load

from azure.ml._restclient.v2021_10_01.models import (
    EarlyTerminationPolicyType,
)
from azure.ml._utils.utils import camel_to_snake
from azure.ml._schema.core.schema import PatchedSchemaMeta
from azure.ml._schema.core.fields import StringTransformedEnum

module_logger = logging.getLogger(__name__)


class EarlyTerminationSchema(metaclass=PatchedSchemaMeta):
    evaluation_interval = fields.Int()
    delay_evaluation = fields.Int()


class BanditPolicySchema(EarlyTerminationSchema):
    type = StringTransformedEnum(
        required=True, allowed_values=EarlyTerminationPolicyType.BANDIT, casing_transform=camel_to_snake
    )
    slack_factor = fields.Float()
    slack_amount = fields.Float()

    @post_load
    def make(self, data, **kwargs):
        from azure.ml.entities import BanditPolicy

        return BanditPolicy(**data)


class MedianStoppingPolicySchema(EarlyTerminationSchema):
    type = StringTransformedEnum(
        required=True, allowed_values=EarlyTerminationPolicyType.MEDIAN_STOPPING, casing_transform=camel_to_snake
    )

    @post_load
    def make(self, data, **kwargs):
        from azure.ml.entities import MedianStoppingPolicy

        return MedianStoppingPolicy(**data)


class TruncationSelectionPolicySchema(EarlyTerminationSchema):
    type = StringTransformedEnum(
        required=True, allowed_values=EarlyTerminationPolicyType.TRUNCATION_SELECTION, casing_transform=camel_to_snake
    )
    truncation_percentage = fields.Int(required=True)

    @post_load
    def make(self, data, **kwargs):
        from azure.ml.entities import TruncationSelectionPolicy

        return TruncationSelectionPolicy(**data)
