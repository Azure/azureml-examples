# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Iterable
from azure.ml._restclient.runhistory import (
    AzureMachineLearningWorkspaces as RunHistoryServiceClient,
)
from azure.ml._restclient.runhistory.models import RunDetailsDto, RunDto, PaginatedRunDto
from azure.ml._dependent_operations import _DependentOperations, OperationScope
from azure.core.paging import ItemPaged


module_logger = logging.getLogger(__name__)


class RunOperations(_DependentOperations):
    def __init__(self, operation_scope: OperationScope, service_client: RunHistoryServiceClient):
        super(RunOperations, self).__init__(operation_scope)
        self._operation = service_client.run

    def get_run_details(self, exp_name: str, run_id: str) -> RunDetailsDto:
        return self._operation.get_details(
            self._operation_scope.subscription_id,
            self._operation_scope.resource_group_name,
            self._workspace_name,
            exp_name,
            run_id,
        )

    def get_run_children(self, exp_name: str, run_id: str) -> Iterable[RunDto]:
        def extract_data(page: PaginatedRunDto):
            return page.continuation_token or None, iter(page.value)

        def get_next(continuation_token: str = None):
            return self._operation.get_child(
                self._workspace_scope.subscription_id,
                self._workspace_scope.resource_group_name,
                self._workspace_name,
                exp_name,
                run_id,
                continuation_token_parameter=continuation_token,
            )

        return ItemPaged(get_next, extract_data)
