# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Dict, Iterable, Optional

from azure.ml._operations import DatastoreOperations
from azure.ml._restclient.v2021_10_01 import AzureMachineLearningWorkspaces as ServiceClient102021
from azure.ml._restclient.v2022_02_01_preview import (
    AzureMachineLearningWorkspaces as ServiceClient022022Preview,
)
from azure.ml._artifacts._artifact_utilities import _check_and_upload_path
from azure.ml._dependent_operations import OperationScope, _DependentOperations
from azure.ml.entities._assets import Data
from azure.ml._artifacts._constants import ASSET_PATH_ERROR, CHANGED_ASSET_PATH_MSG
from azure.ml._utils._asset_utils import (
    _create_or_update_autoincrement,
    _get_latest,
    _resolve_label_to_asset,
    _archive_or_restore,
)
from azure.ml._utils.utils import get_list_view_type

module_logger = logging.getLogger(__name__)


class DataOperations(_DependentOperations):
    def __init__(
        self,
        operation_scope: OperationScope,
        service_client_10_2021: ServiceClient102021,
        service_client_02_2022_preview: ServiceClient022022Preview,
        datastore_operations: DatastoreOperations,
        **kwargs: Dict,
    ):

        super(DataOperations, self).__init__(operation_scope)
        self._operation_2021_10 = service_client_10_2021.dataset_versions
        self._container_operation_2021_10 = service_client_10_2021.dataset_containers
        self._operation_2022_02_preview = service_client_02_2022_preview.data_versions
        self._container_operation_2022_02_preview = service_client_02_2022_preview.data_containers
        self._datastore_operation = datastore_operations
        self._init_kwargs = kwargs

        # Maps a label to a function which given an asset name,
        # returns the asset associated with the label
        self._managed_label_resolver = {"latest": self._get_latest_version}

    def list(self, name: Optional[str] = None, include_archived: bool = False) -> Iterable[Data]:
        """List the data assets of the workspace.

        :param name: Name of a specific data asset, optional.
        :type name: Optional[str]
        :param include_archived: A flag to indicate whether to return archived data assets and active data assets. Default: False.
        :type include_archived: Optional[bool]
        :return: An iterator like instance of Data objects
        :rtype: ~azure.core.paging.ItemPaged[Data]
        """
        list_view_type = get_list_view_type(include_archived=include_archived)
        if name:
            return self._operation_2021_10.list(
                name=name,
                workspace_name=self._workspace_name,
                cls=lambda objs: [Data._from_rest_object(obj) for obj in objs],
                list_view_type=list_view_type,
                **self._scope_kwargs,
            )
        else:
            return self._container_operation_2021_10.list(
                workspace_name=self._workspace_name,
                cls=lambda objs: [Data._from_container_rest_object(obj) for obj in objs],
                list_view_type=list_view_type,
                **self._scope_kwargs,
            )

    def get(self, name: str, version: str = None, label: str = None) -> Data:
        """Get the specified data asset.

        :param name: Name of data asset.
        :type name: str
        :param version: Version of data asset.
        :type version: str
        :param label: Label of the data asset. (mutually exclusive with version)
        :type label: str
        :return: Data asset object.
        """
        if version and label:
            raise Exception("Cannot specify both version and label.")

        if label:
            return _resolve_label_to_asset(self, name, label)

        if not version:
            raise Exception("Must provide either version or label.")
        data_version_resource = self._operation_2021_10.get(
            name,
            version,
            self._resource_group_name,
            self._workspace_name,
            **self._init_kwargs,
        )

        return Data._from_rest_object(data_version_resource)

    def create_or_update(self, data: Data) -> Data:
        """Returns created or updated data asset.

        If not already in storage, asset will be uploaded to datastore name specified in data.datastore or the workspace's default datastore.

        :param data: Data asset object.
        :type data: Data
        :return: Data asset object.
        """
        name = data.name
        version = data.version

        data, _ = _check_and_upload_path(artifact=data, asset_operations=self)
        data_version_resource = data._to_rest_object()
        auto_increment_version = data._auto_increment_version
        try:
            if auto_increment_version:
                result = _create_or_update_autoincrement(
                    name=data.name,
                    body=data_version_resource,
                    version_operation=self._operation_2021_10,
                    container_operation=self._container_operation_2021_10,
                    resource_group_name=self._operation_scope.resource_group_name,
                    workspace_name=self._workspace_name,
                    **self._init_kwargs,
                )
            else:
                result = self._operation_2021_10.create_or_update(
                    name=name,
                    version=version,
                    workspace_name=self._workspace_name,
                    body=data_version_resource,
                    **self._scope_kwargs,
                )
        except Exception as e:
            # service side raises an exception if we attempt to update an existing asset's asset path
            if str(e) == ASSET_PATH_ERROR:
                raise Exception(CHANGED_ASSET_PATH_MSG)
            else:
                raise e

        return Data._from_rest_object(result)

    def archive(self, name: str, version: str = None, label: str = None) -> None:
        """Archive a dataset asset.

        :param name: Name of dataset asset.
        :type name: str
        :param version: Version of dataset asset.
        :type version: str
        :param label: Label of the dataset asset. (mutually exclusive with version)
        :type label: str
        :return: None
        """

        _archive_or_restore(
            asset_operations=self,
            version_operation=self._operation_2022_02_preview,
            container_operation=self._container_operation_2022_02_preview,
            is_archived=True,
            name=name,
            version=version,
            label=label,
        )

    def restore(self, name: str, version: str = None, label: str = None) -> None:
        """Restore an archived dataset asset.

        :param name: Name of dataset asset.
        :type name: str
        :param version: Version of dataset asset.
        :type version: str
        :param label: Label of the dataset asset. (mutually exclusive with version)
        :type label: str
        :return: None
        """

        _archive_or_restore(
            asset_operations=self,
            version_operation=self._operation_2022_02_preview,
            container_operation=self._container_operation_2022_02_preview,
            is_archived=False,
            name=name,
            version=version,
            label=label,
        )

    def _get_latest_version(self, name: str) -> Data:
        """Returns the latest version of the asset with the given name.

        Latest is defined as the most recently created, not the most recently updated.
        """
        result = _get_latest(name, self._operation_2021_10, self._resource_group_name, self._workspace_name)
        return Data._from_rest_object(result)
