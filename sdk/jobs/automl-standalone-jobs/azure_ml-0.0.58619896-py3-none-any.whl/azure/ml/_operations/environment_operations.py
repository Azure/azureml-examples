# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import logging
from typing import Any, Iterable

from azure.ml._artifacts._artifact_utilities import _upload_to_datastore, _check_and_upload_env_build_context
from azure.ml._constants import ARM_ID_PREFIX, AzureMLResourceType
from azure.ml._operations import DatastoreOperations
from azure.ml._dependent_operations import _DependentOperations, OperationScope, OperationsContainer
from azure.ml._restclient.v2022_02_01_preview.models import (
    EnvironmentVersionData,
)
from azure.ml._restclient.v2022_02_01_preview import (
    AzureMachineLearningWorkspaces as ServiceClient022022,
)
from azure.ml.entities._assets import Environment
from azure.ml._utils._asset_utils import (
    _create_or_update_autoincrement,
    _get_latest,
    _resolve_label_to_asset,
    _archive_or_restore,
)
from azure.ml._utils.utils import get_list_view_type

module_logger = logging.getLogger(__name__)


class EnvironmentOperations(_DependentOperations):
    def __init__(
        self,
        operation_scope: OperationScope,
        service_client: ServiceClient022022,
        all_operations: OperationsContainer,
        **kwargs: Any
    ):
        super(EnvironmentOperations, self).__init__(operation_scope)
        self._kwargs = kwargs
        self._containers_operations = service_client.environment_containers
        self._version_operations = service_client.environment_versions
        self._all_operations = all_operations
        self._datastore_operation = all_operations.all_operations[AzureMLResourceType.DATASTORE]

        # Maps a label to a function which given an asset name,
        # returns the asset associated with the label
        self._managed_label_resolver = {"latest": self._get_latest_version}

    def create_or_update(self, environment: Environment) -> Environment:
        """Returns created or updated environment asset.

        :param environment: Environment object
        :type environment: Environment
        :return: Created or updated Environment object
        """

        environment = _check_and_upload_env_build_context(environment=environment, operations=self)

        env_version_resource = environment._to_rest_object()

        if environment._auto_increment_version:
            env_rest_obj = _create_or_update_autoincrement(
                name=environment.name,
                body=env_version_resource,
                version_operation=self._version_operations,
                container_operation=self._containers_operations,
                workspace_name=self._workspace_name,
                **self._scope_kwargs,
                **self._kwargs,
            )
        else:
            env_rest_obj = self._version_operations.create_or_update(
                name=environment.name,
                version=environment.version,
                workspace_name=self._workspace_name,
                body=env_version_resource,
                **self._scope_kwargs,
                **self._kwargs,
            )

        return Environment._from_rest_object(env_rest_obj)

    def _get(self, name: str, version: str = None) -> EnvironmentVersionData:
        if version:
            return self._version_operations.get(
                name=name,
                version=version,
                workspace_name=self._workspace_name,
                **self._scope_kwargs,
                **self._kwargs,
            )
        else:
            return self._containers_operations.get(
                name=name,
                workspace_name=self._workspace_name,
                **self._scope_kwargs,
                **self._kwargs,
            )

    def get(self, name: str, version: str = None, label: str = None) -> Environment:
        """Returns the specified environment asset.

        :param name: Name of the environment.
        :type name: str
        :param version: Version of the environment.
        :type version: str
        :param label: Label of the environment. (mutually exclusive with version)
        :type label: str
        :return: Environment object
        """
        if version and label:
            raise Exception("Cannot specify both version and label.")

        if label:
            return _resolve_label_to_asset(self, name, label)

        if not version:
            raise Exception("Must provide either version or label.")
        name = _preprocess_environment_name(name)
        env_version_resource = self._get(name, version)

        return Environment._from_rest_object(env_version_resource)

    def list(self, name: str = None, include_archived: bool = False) -> Iterable[Environment]:
        """List all environment assets in workspace.

        :param name: Name of the environment.
        :type name: str
        :param include_archived: A flag to indicate whether to return archived environments and active environments. Default: False.
        :type include_archived: Optional[bool]
        :return: An iterator like instance of Environment objects
        :rtype: ~azure.core.paging.ItemPaged[Environment]
        """
        list_view_type = get_list_view_type(include_archived=include_archived)
        if name:
            return self._version_operations.list(
                name=name,
                workspace_name=self._workspace_name,
                cls=lambda objs: [Environment._from_rest_object(obj) for obj in objs],
                list_view_type=list_view_type,
                **self._scope_kwargs,
                **self._kwargs,
            )
        else:
            return self._containers_operations.list(
                workspace_name=self._workspace_name,
                cls=lambda objs: [Environment._from_container_rest_object(obj) for obj in objs],
                list_view_type=list_view_type,
                **self._scope_kwargs,
                **self._kwargs,
            )

    def archive(self, name: str, version: str = None, label: str = None) -> None:
        """
        Archive an environment or an environment version.
        :param name: Name of the environment.
        :type name: str
        :param version: Version of the environment.
        :type version: str
        :param label: Label of the environment. (mutually exclusive with version)
        :type label: str
        """
        name = _preprocess_environment_name(name)
        _archive_or_restore(
            asset_operations=self,
            version_operation=self._version_operations,
            container_operation=self._containers_operations,
            is_archived=True,
            name=name,
            version=version,
            label=label,
        )

    def restore(self, name: str, version: str = None, label: str = None, **kwargs) -> None:
        """
        Restore an archived environment version.
        :param name: Name of the environment.
        :type name: str
        :param version: Version of the environment.
        :type version: str
        :param label: Label of the environment. (mutually exclusive with version)
        :type label: str
        """
        name = _preprocess_environment_name(name)
        _archive_or_restore(
            asset_operations=self,
            version_operation=self._version_operations,
            container_operation=self._containers_operations,
            is_archived=False,
            name=name,
            version=version,
            label=label,
        )

    def _get_latest_version(self, name: str) -> Environment:
        """Returns the latest version of the asset with the given name.

        Latest is defined as the most recently created, not the most recently updated.
        """
        result = _get_latest(name, self._version_operations, self._resource_group_name, self._workspace_name)
        return Environment._from_rest_object(result)


def _preprocess_environment_name(environment_name: str) -> str:
    if environment_name.startswith(ARM_ID_PREFIX):
        return environment_name[len(ARM_ID_PREFIX) :]
    return environment_name
