# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azure.ml._schema.core.schema import YamlFileSchema

from azure.ml._schema.assets.dataset_paths import PathSchema
from marshmallow import fields, post_load, ValidationError, validates_schema

from azure.ml._schema import NestedField
from azure.ml._constants import BASE_PATH_CONTEXT_KEY


class MLTableMetadataSchema(YamlFileSchema):
    paths = fields.List(NestedField(PathSchema()), required=True)
    transformations = fields.List(fields.Raw())

    @post_load
    def make(self, data, **kwargs):
        data[BASE_PATH_CONTEXT_KEY] = self.context[BASE_PATH_CONTEXT_KEY]
        return data

    @validates_schema
    def validate_mltable_paths(self, data, **kwargs):
        if data["paths"] is None:
            raise ValidationError("paths is required for mltable data.")

    @validates_schema
    def validate_transformations(self, data, **kwargs):
        transformations = data["transformations"]
        return transformations is None or isinstance(transformations, list) or isinstance(transformations, str)
