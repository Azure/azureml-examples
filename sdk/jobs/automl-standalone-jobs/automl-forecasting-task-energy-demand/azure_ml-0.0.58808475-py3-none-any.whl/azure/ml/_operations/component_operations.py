# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import logging
import tempfile
from pathlib import Path
from typing import Dict, Iterable, Union

from azure.ml._operations import OperationOrchestrator
from azure.ml._restclient.v2021_10_01 import AzureMachineLearningWorkspaces as ServiceClient102021
from azure.ml._restclient.v2021_10_01.models import (
    ComponentContainerDetails,
)
from azure.ml._dependent_operations import _DependentOperations, OperationScope, OperationsContainer
from azure.ml._utils.utils import hash_dict
from azure.ml._constants import AzureMLResourceType
from azure.ml.entities import ComponentVersion, CommandComponentVersion, Code
from azure.ml._utils._asset_utils import _create_or_update_autoincrement, _resolve_label_to_asset, _get_latest
from azure.ml._utils._arm_id_utils import is_ARM_id_for_resource

from azure.ml._telemetry import AML_INTERNAL_LOGGER_NAMESPACE, ActivityType, monitor_with_activity

logger = logging.getLogger(AML_INTERNAL_LOGGER_NAMESPACE + __name__)
logger.propagate = False
module_logger = logging.getLogger(__name__)
CODE_IMMUTABLE_ERROR = "The field CodeName is immutable."
CHANGE_CODE_IMMUTABLE_ERROR = (
    "Component {} already exists with a different component code. "
    "The component code field is immutable, try specifying a new version."
)
COMPONENT_PLACEHOLDER = "COMPONENT_PLACEHOLDER"
COMPONENT_CODE_PLACEHOLDER = "command_component: code_placeholder"


class ComponentOperations(_DependentOperations):
    def __init__(
        self,
        operation_scope: OperationScope,
        service_client: ServiceClient102021,
        all_operations: OperationsContainer,
        **kwargs: Dict,
    ):
        super(ComponentOperations, self).__init__(operation_scope)
        if "app_insights_handler" in kwargs:
            logger.addHandler(kwargs.pop("app_insights_handler"))
        self._version_operation = service_client.component_versions
        self._container_operation = service_client.component_containers
        self._all_operations = all_operations
        self._init_args = kwargs
        # Maps a label to a function which given an asset name,
        # returns the asset associated with the label
        self._managed_label_resolver = {"latest": self._get_latest_version}

    @monitor_with_activity(logger, "Component.List", ActivityType.PUBLICAPI)
    def list(self, name: Union[str, None] = None) -> Iterable[Union[ComponentVersion, ComponentContainerDetails]]:
        if name:
            return self._version_operation.list(
                name,
                self._resource_group_name,
                self._workspace_name,
                **self._init_args,
                cls=lambda objs: [ComponentVersion._from_rest_object(obj) for obj in objs],
            )
        return self._container_operation.list(
            self._resource_group_name,
            self._workspace_name,
            **self._init_args,
        )

    @monitor_with_activity(logger, "Component.Get", ActivityType.PUBLICAPI)
    def get(self, name: str, version: str = None, label: str = None) -> ComponentVersion:
        """Returns information about the specified component.

        :param name: Name of the code component.
        :type name: str
        :param version: Version of the component.
        :type version: str
        :param label: Label of the component. (mutually exclusive with version)
        :type label: str
        """
        if version and label:
            raise Exception("Cannot specify both version and label.")

        if label:
            return _resolve_label_to_asset(self, name, label)

        if not version:
            raise Exception("Must provide either version or label.")
        result = self._version_operation.get(
            name=name,
            version=version,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            **self._init_args,
        )
        component = ComponentVersion._from_rest_object(result)
        return component

    @monitor_with_activity(logger, "Component.CreateOrUpdate", ActivityType.PUBLICAPI)
    def create_or_update(self, component: ComponentVersion) -> ComponentVersion:
        # Create all dependent resources
        self._upload_dependencies(component)

        # For anonymous component, we use code hash + yaml hash(if code is None) as component name
        # so the same anonymous component(same interface and same code) won't be created again.
        if component._is_anonymous is True:

            component.name = get_anonymous_component_name(component)

        rest_component_resource = component._to_rest_object()
        try:
            if component.auto_increment_version:
                result = _create_or_update_autoincrement(
                    name=component.name,
                    body=rest_component_resource,
                    version_operation=self._version_operation,
                    container_operation=self._container_operation,
                    resource_group_name=self._operation_scope.resource_group_name,
                    workspace_name=self._workspace_name,
                    **self._init_args,
                )
            else:
                result = self._version_operation.create_or_update(
                    name=rest_component_resource.name,
                    version=component.version,
                    resource_group_name=self._resource_group_name,
                    workspace_name=self._workspace_name,
                    body=rest_component_resource,
                    **self._init_args,
                )
        except Exception as e:
            # If user tries to create same component with different code, raise exception with meaningful error msg.
            if CODE_IMMUTABLE_ERROR in str(e):
                # TODO: the exception type might be user error.
                raise Exception(CHANGE_CODE_IMMUTABLE_ERROR.format(rest_component_resource.name))
            raise e

        return ComponentVersion._from_rest_object(result)

    def _get_latest_version(self, component_name: str) -> ComponentVersion:
        """Returns the latest version of the asset with the given name.

        Latest is defined as the most recently created, not the most recently updated.
        """
        result = _get_latest(component_name, self._version_operation, self._resource_group_name, self._workspace_name)
        return ComponentVersion._from_rest_object(result)

    def _upload_dependencies(self, component: ComponentVersion) -> None:
        orchestrators = OperationOrchestrator(self._all_operations, self._operation_scope)
        resolver = orchestrators.get_asset_arm_id

        if type(component) is CommandComponentVersion:
            if component.code is not None:
                if isinstance(component.code, Code):
                    component.code = resolver(component.code, azureml_type=AzureMLResourceType.CODE)
                elif not is_ARM_id_for_resource(component.code, AzureMLResourceType.CODE):
                    component.code = resolver(
                        Code(base_path=component._base_path, path=component.code), azureml_type=AzureMLResourceType.CODE
                    )
            else:
                # Hack: when code not specified, we generated a file which contains COMPONENT_PLACEHOLDER as code
                # This hack was introduced because job does not allow running component without a code and we need to
                # make sure when component updated some field(eg: description), the code remains the same.
                # Benefit of using a constant code for all components without code is this will generate same code for
                # anonymous components which enables component reuse
                with tempfile.TemporaryDirectory() as tmp_dir:
                    code_file_path = Path(tmp_dir) / COMPONENT_PLACEHOLDER
                    with open(code_file_path, "w") as f:
                        f.write(COMPONENT_CODE_PLACEHOLDER)
                    component.code = resolver(
                        Code(base_path=component._base_path, path=code_file_path), azureml_type=AzureMLResourceType.CODE
                    )
            if component.environment:
                component.environment = resolver(component.environment, azureml_type=AzureMLResourceType.ENVIRONMENT)
        else:
            raise Exception(f"Non supported component type: {type(component)}")


def get_anonymous_component_name(component: ComponentVersion) -> str:
    """Return the name of anonymous component.

    same anonymous component(same code and interface) will have same name.
    """
    component_interface_dict = component._to_dict()
    # omit name since anonymous component's original name is random guid
    return hash_dict(component_interface_dict, keys_to_omit=["name", "id"])
