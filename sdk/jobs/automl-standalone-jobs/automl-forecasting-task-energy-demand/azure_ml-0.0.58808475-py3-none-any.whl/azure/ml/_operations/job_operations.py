# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import json
import logging
import os.path
from os import PathLike
from os.path import sep
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Dict, Iterable, Optional, Union
from multiprocessing.pool import ThreadPool
from itertools import chain

from azure.ml.entities._assets._artifacts.code import Code

try:
    from typing import Protocol  # For python >= 3.8
except ImportError:
    from typing_extensions import Protocol  # For python < 3.8

from azure.ml._constants import PipelineConstants, BATCH_JOB_CHILD_RUN_NAME, BATCH_JOB_CHILD_RUN_OUTPUT_NAME
from azure.ml.entities._job.job_errors import JobParsingError

import jwt
from azure.identity import ChainedTokenCredential
from azure.core.exceptions import HttpResponseError

from azure.ml._artifacts._artifact_utilities import download_artifact_from_aml_uri, aml_datastore_path_exists
from azure.ml._operations.run_history_constants import RunHistoryConstants
from azure.ml._restclient.v2022_02_01_preview import (
    AzureMachineLearningWorkspaces as ServiceClient022022Preview,
)
from azure.ml._restclient.v2022_02_01_preview.models import JobBaseData, AmlToken, UserIdentity, JobType as RestJobType
from azure.ml._restclient.runhistory import (
    AzureMachineLearningWorkspaces as ServiceClientRunHistory,
)
from azure.ml._utils._storage_utils import get_storage_client
from azure.ml._utils.utils import create_session_with_retry, download_text_from_url, is_url, get_list_view_type
from azure.ml._dependent_operations import OperationsContainer, OperationScope, _DependentOperations
from azure.ml._constants import (
    AzureMLResourceType,
    TID_FMT,
    DEFAULT_SCOPES,
    AZUREML_SCOPES,
    AZUREML_RESOURCE_PROVIDER,
    LEVEL_ONE_NAMED_RESOURCE_ID_FORMAT,
    LOCAL_COMPUTE_TARGET,
    SHORT_URI_FORMAT,
    AssetTypes,
)
from azure.ml.entities import (
    AutoMLJob,
    CommandJob,
    Job,
    SweepJob,
    PipelineJob,
    ComponentVersion,
    CommandComponentVersion,
    _BaseJob,
)
from azure.ml.entities._job.input_output_entry import InputOutputEntry, JobInput, JobOutput
from azure.ml.entities._job.pipeline.component_job import CommandComponent, BaseComponent
from azure.ml.entities._job.pipeline.pipeline_job_settings import PipelineJobSettings
from azure.ml._artifacts._constants import PROCESSES_PER_CORE
from azure.ml._utils.utils import modified_operation_client
from azure.ml._utils._arm_id_utils import is_ARM_id_for_resource
from azure.ml._artifacts._artifact_utilities import _upload_and_generate_remote_uri

from .job_ops_helper import get_git_properties, stream_logs_until_completion, get_children
from .local_job_invoker import is_local_run, start_run_if_local
from .operation_orchestrator import OperationOrchestrator
from .run_operations import RunOperations
from ..entities._job.pipeline._io import InputsAttrDict, Input as PipelineInput

if TYPE_CHECKING:
    from azure.ml._operations import DatastoreOperations
from azure.ml._telemetry import AML_INTERNAL_LOGGER_NAMESPACE, ActivityType, monitor_with_activity

logger = logging.getLogger(AML_INTERNAL_LOGGER_NAMESPACE + __name__)
logger.propagate = False
module_logger = logging.getLogger(__name__)


class JobOperations(_DependentOperations):
    def __init__(
        self,
        operation_scope: OperationScope,
        service_client_02_2022_preview: ServiceClient022022Preview,
        service_client_run_history: ServiceClientRunHistory,
        all_operations: OperationsContainer,
        credential: ChainedTokenCredential,
        **kwargs: Any,
    ):
        super(JobOperations, self).__init__(operation_scope)
        if "app_insights_handler" in kwargs:
            logger.addHandler(kwargs.pop("app_insights_handler"))
        self._operation_2022_02_preview = service_client_02_2022_preview.jobs
        self._all_operations = all_operations
        self._kwargs = kwargs
        self._runs = RunOperations(operation_scope, service_client_run_history)
        self._stream_logs_until_completion = stream_logs_until_completion
        self._container = "azureml"
        self._credential = credential
        self._orchestrators = OperationOrchestrator(self._all_operations, self._operation_scope)

    @monitor_with_activity(logger, "Job.List", ActivityType.PUBLICAPI)
    def list(self, include_archived: bool = False, parent_job_name: str = None) -> Iterable[Job]:
        """List jobs of the workspace.

        :param include_archived: A flag to indicate whether to return archived jobs and active jobs. Default: False.
        :type include_archived: Optional[bool]
        :param parent_job_name: When provided, returns children of named job
        :type parent_job_name: Optional[str]
        :return: An iterator like instance of Job objects
        :rtype: ~azure.core.paging.ItemPaged[Job]
        """

        if parent_job_name:
            parent_job = self.get(parent_job_name)
            with modified_operation_client(self._runs._operation, self._get_workspace_url()):
                child_runs = self._runs.get_run_children(parent_job.experiment_name, parent_job.name)
            return (self.get(run.run_id) for run in child_runs)

        list_view_type = get_list_view_type(include_archived=include_archived)

        return self._operation_2022_02_preview.list(
            self._operation_scope.resource_group_name,
            self._workspace_name,
            cls=lambda objs: [self._handle_rest_errors(obj) for obj in objs],
            list_view_type=list_view_type,
            **self._kwargs,
        )

    def _handle_rest_errors(self, job_object):
        """Handle errors while resolving azureml_id's during list operation"""
        try:
            return self._resolve_azureml_id(Job._from_rest_object(job_object))
        except JobParsingError:
            pass

    @monitor_with_activity(logger, "Job.Get", ActivityType.PUBLICAPI)
    def get(self, name: str) -> Job:
        """Get a job resource.

        :param str name: Name of the job.
        :return: Job object retrieved from the service.
        :rtype: Job
        :raise: ResourceNotFoundError if can't find a job matching provided name.
        """
        job_object = self._get_job(name)
        job = Job._from_rest_object(job_object)
        if job_object.properties.job_type != RestJobType.AUTO_ML:
            # resolvers do not work with the old contract, leave the ids as is
            job = self._resolve_azureml_id(job)
        return job

    @monitor_with_activity(logger, "Job.Cancel", ActivityType.PUBLICAPI)
    def cancel(self, name: str) -> None:
        """Cancel job resource.

        :param str name: Name of the job.
        :return: None, or the result of cls(response)
        :rtype: None
        :raise: ResourceNotFoundError if can't find a job matching provided name.
        """
        return self._operation_2022_02_preview.cancel(
            id=name,
            resource_group_name=self._operation_scope.resource_group_name,
            workspace_name=self._workspace_name,
            **self._kwargs,
        )

    @monitor_with_activity(logger, "Job.CreateOrUpdate", ActivityType.PUBLICAPI)
    def create_or_update(
        self,
        job: Job,
        *,
        description: str = None,
        compute: str = None,
        tags: dict = None,
        experiment_name: str = None,
        **kwargs,
    ) -> Job:
        """Create or update a job, if there're inline defined entities, e.g. Environment, Code, they'll be created together with the job.

        :param Job job: Job definition or object which can be translate to a job.
        :param description: Description to overwrite when submitting the pipeline.
        :type description: str
        :param compute: Compute target to overwrite when submitting the pipeline.
        :type compute: str
        :param tags: Tags to overwrite when submitting the pipeline.
        :type tags: dict
        :param experiment_name: Name of the experiment the job will be created under, if None is provided, job will be created under experiment 'Default'.
        :type experiment_name: str
        :return: Created or updated job.
        :rtype: Job
        """
        # Set job properties before submission
        if description is not None:
            job.description = description
        if compute is not None:
            job.compute = compute
        if tags is not None:
            job.tags = tags
        if experiment_name is not None:
            job.experiment_name = experiment_name

        # Create all dependent resources
        self._resolve_arm_id_or_upload_dependencies(job)

        git_props = get_git_properties()
        # Do not add git props if they already exist in job properties.
        # This is for update specifically-- if the user switches branches and tries to update their job, the request will fail since the git props will be repopulated.
        # MFE does not allow existing properties to be updated, only for new props to be added
        if not any(prop_name in job.properties for prop_name in git_props.keys()):
            job.properties = {**job.properties, **git_props}
        rest_job_resource = job._to_rest_object()

        # Make a copy of self._kwargs instead of contaminate the original one
        kwargs = dict(**self._kwargs)
        if hasattr(rest_job_resource.properties, "identity") and (
            rest_job_resource.properties.identity is None
            or isinstance(rest_job_resource.properties.identity, UserIdentity)
        ):
            self._set_headers_with_user_aml_token(kwargs)
        result = self._operation_2022_02_preview.create_or_update(
            id=rest_job_resource.name,  # type: ignore
            resource_group_name=self._operation_scope.resource_group_name,
            workspace_name=self._workspace_name,
            body=rest_job_resource,
            **kwargs,
        )
        if is_local_run(result):
            ws_base_url = self._all_operations.all_operations[
                AzureMLResourceType.WORKSPACE
            ]._operation._client._base_url
            snapshot_id = start_run_if_local(result, self._credential, ws_base_url)
            # in case of local run, the first create/update call to MFE returns the
            # request for submitting to ES. Once we request to ES and start the run, we
            # need to put the same body to MFE to append user tags etc.
            job_object = self._get_job(rest_job_resource.name)
            if result.properties.tags is not None:
                for tag_name, tag_value in rest_job_resource.properties.tags.items():
                    job_object.properties.tags[tag_name] = tag_value
            if result.properties.properties is not None:
                for prop_name, prop_value in rest_job_resource.properties.properties.items():
                    job_object.properties.properties[prop_name] = prop_value
            if snapshot_id is not None:
                job_object.properties.properties["ContentSnapshotId"] = snapshot_id

            result = self._operation_2022_02_preview.create_or_update(
                id=rest_job_resource.name,  # type: ignore
                resource_group_name=self._operation_scope.resource_group_name,
                workspace_name=self._workspace_name,
                body=job_object,
                **kwargs,
            )
        return self._resolve_azureml_id(Job._from_rest_object(result))

    def _archive_or_restore(self, name: str, is_archived: bool):
        job_object = self._get_job(name)
        job_object.properties.is_archived = is_archived

        self._operation_2022_02_preview.create_or_update(
            id=job_object.name,
            resource_group_name=self._operation_scope.resource_group_name,
            workspace_name=self._workspace_name,
            body=job_object,
        )

    @monitor_with_activity(logger, "Job.Archive", ActivityType.PUBLICAPI)
    def archive(self, name: str) -> None:
        """Archive a job or restore an archived job.

        :param name: Name of the job.
        :type name: str
        :raise: ResourceNotFoundError if can't find a job matching provided name.
        """

        self._archive_or_restore(name=name, is_archived=True)

    @monitor_with_activity(logger, "Job.Restore", ActivityType.PUBLICAPI)
    def restore(self, name: str) -> None:
        """Archive a job or restore an archived job.

        :param name: Name of the job.
        :type name: str
        :raise: ResourceNotFoundError if can't find a job matching provided name.
        """

        self._archive_or_restore(name=name, is_archived=False)

    @monitor_with_activity(logger, "Job.Stream", ActivityType.PUBLICAPI)
    def stream(self, name: str) -> None:
        """Stream logs of a job.

        :param str name: Name of the job.
        :raise: ResourceNotFoundError if can't find a job matching provided name.
        """
        job_object = self._get_job(name)

        try:
            self._runs._operation._client._base_url = self._get_workspace_url()
            self._stream_logs_until_completion(
                self._runs, job_object, self._all_operations.all_operations[AzureMLResourceType.DATASTORE]
            )
        except Exception:
            raise

    @monitor_with_activity(logger, "Job.Download", ActivityType.PUBLICAPI)
    def download(
        self,
        name: str,
        *,
        download_path: Union[PathLike, str] = Path.cwd(),
        output_name: str = None,
        all: bool = False,
    ) -> None:
        """Download logs and output of a job.

        :param str name: Name of a job.
        :param Union[PathLike, str] download_path: Local path as download destination, defaults to current working directory.
        :param str output_name: Named output to download, defaults to None.
        :param bool all: Whether to download logs and all named outputs, defaults to False.
        """
        job_details = self.get(name)
        job_status = job_details.status
        if job_status not in RunHistoryConstants.TERMINAL_STATUSES:
            raise Exception(
                "This job is in state {}. Download is allowed only in states {}".format(
                    job_status, RunHistoryConstants.TERMINAL_STATUSES
                )
            )

        datastore_operations: "DatastoreOperations" = self._all_operations.all_operations[AzureMLResourceType.DATASTORE]
        is_batch_job = job_details.tags.get("azureml.batchrun", None) == "true"
        if is_batch_job:
            self._download_batch_job(job_details, download_path)
            return

        to_download = []
        download_path = Path(download_path)
        try:
            outputs = job_details.outputs
        except AttributeError:
            outputs = {}

        # fetch uri of default artifact store
        if all or not output_name:
            # "default" output is added by the service, use it if present and
            # prevent it from being treated as a named_output
            uri = self._get_named_output_uri(job_details.name, "default", outputs)
            if uri:
                outputs.pop("default", None)
            else:
                uri = SHORT_URI_FORMAT.format("workspaceartifactstore", f"ExperimentRun/dcid.{job_details.name}/")
            to_download.append(dict(uri=uri, destination=download_path / "artifacts"))

        named_outputs_to_download = []

        if all:
            named_outputs_to_download = outputs.keys()
        elif output_name:
            named_outputs_to_download = [output_name]

        # fetch uri of named outputs
        for name in named_outputs_to_download:
            uri = self._get_named_output_uri(job_details.name, name, outputs)
            if not uri:
                module_logger.warning(
                    f'Could not download output "{name}" for job "{job_details.name}" (job status: {job_details.status})'
                )
                continue
            to_download.append(dict(uri=uri, destination=download_path / "named-outputs" / name))

        # Download all requested artifacts
        for d in to_download:
            module_logger.info(f"Downloading artifact {d['uri']} to {d['destination']}")
            download_artifact_from_aml_uri(**d, datastore_operation=datastore_operations)

    def _get_named_output_uri(
        self, job_name: str, output_name: str, outputs: Dict[str, JobOutput] = None
    ) -> Optional[str]:
        """Gets the URI pointing to the named output of a job

        :param str job_name: Run ID of the job
        :param str output_name: Output to fetch URI for
        :param dict[str, JobOutput] outputs: Map of named_outputs to corresponding JobOutput
        :return Optional[str]: Returns URI if found, None if not
        """
        output: Optional[JobOutput] = outputs and outputs.get(output_name, None)
        uri = None
        # URI output
        if output and output.path:
            uri = output.path
        else:
            # A job's output is not always reported in the outputs dict, but
            # doesn't currently have a user configurable location.
            # Perform a search of known paths to find output
            # TODO: Remove once job output locations are reliably returned from the service
            datastore_operations: "DatastoreOperations" = self._all_operations.all_operations[
                AzureMLResourceType.DATASTORE
            ]
            default_datastore = datastore_operations.get_default().name

            potential_uris = [
                SHORT_URI_FORMAT.format(default_datastore, f"azureml/{job_name}/{output_name}/"),
                SHORT_URI_FORMAT.format(default_datastore, f"dataset/{job_name}/{output_name}/"),
            ]

            for potential_uri in potential_uris:
                if aml_datastore_path_exists(potential_uri, datastore_operations):
                    uri = potential_uri
                    break

        return uri

    def _download_batch_job(self, job_details: PipelineJob, download_path: Path):
        datastore_operations: "DatastoreOperations" = self._all_operations.all_operations[AzureMLResourceType.DATASTORE]
        # Download scoring output, which is the "score" output of the child job named "batchscoring"
        with modified_operation_client(self._runs._operation, self._get_workspace_url()):
            for child in self._runs.get_run_children(job_details.experiment_name, job_details.name):
                if child.name == BATCH_JOB_CHILD_RUN_NAME:
                    uri = self._get_named_output_uri(child.run_id, BATCH_JOB_CHILD_RUN_OUTPUT_NAME)
                    if not uri:
                        raise Exception(
                            f'Could not download scoring results file for batch job "{job_details.name}" (job status: {job_details.status})'
                        )
                    module_logger.info(f"Downloading artifact {uri} to {download_path}")
                    download_artifact_from_aml_uri(uri, download_path, datastore_operations)
                    return

    def _get_job(self, name: str) -> JobBaseData:
        return self._operation_2022_02_preview.get(
            id=name,
            resource_group_name=self._operation_scope.resource_group_name,
            workspace_name=self._workspace_name,
            **self._kwargs,
        )

    def _get_workspace_url(self, url_key="history"):
        discovery_url = (
            self._all_operations.all_operations[AzureMLResourceType.WORKSPACE]
            .get(self._operation_scope.workspace_name)
            .discovery_url
        )
        all_urls = json.loads(download_text_from_url(discovery_url, create_session_with_retry()))
        return all_urls[url_key]

    def _resolve_arm_id_or_upload_dependencies(self, job: Job) -> None:
        """This method converts name or name:version to ARM id. Or it registers/uploads nested dependencies.

        :param job: the job resource entity
        :type job: Job
        :return: the job resource entity that nested dependencies are resolved
        :rtype: Job
        """
        self._resolve_arm_id_or_azureml_id(job, self._orchestrators.get_asset_arm_id)

        if isinstance(job, PipelineJob):
            # Resolve top-level inputs
            self._resolve_job_inputs(map(lambda x: x._data, job.inputs.values()), job._base_path)
            if job.jobs:
                for _, job_instance in job.jobs.items():
                    # resolve inputs for each job's component
                    if isinstance(job_instance, CommandComponent):
                        command_component: CommandComponent = job_instance
                        self._resolve_job_inputs(
                            map(lambda x: x._data, command_component.inputs.values()), job._base_path
                        )
        elif isinstance(job, AutoMLJob):
            self._resolve_automl_job_inputs(job)
        else:
            try:
                self._resolve_job_inputs(job.inputs.values(), job._base_path)
            except AttributeError:
                # If the job object doesn't have "inputs" attribute, we don't need to resolve. E.g. AutoML jobs
                pass

    def _resolve_automl_job_inputs(self, job: AutoMLJob) -> None:
        """This method resolves the inputs for AutoML jobs.

        :param job: the job resource entity
        :type job: AutoMLJob
        """
        # for tabular
        #   get training/validation/test data
        #   resolve job_inputs
        #   convert to mltablejobinput

        from azure.ml.entities._job.automl.tabular import AutoMLTabular

        if isinstance(job, AutoMLTabular):
            data = job._data
            self._resolve_job_input(data.training_data, job._base_path)

            validation_data = data.validation_data
            if validation_data.data is not None:
                self._resolve_job_input(data.validation_data.data, job._base_path)

            test_data = data.test_data
            if test_data.data:
                self._resolve_job_input(data.training_data.data, job._base_path)

    def _resolve_azureml_id(self, job: Job) -> Job:
        """This method converts ARM id to name or name:version for nested entities.

        :param job: the job resource entity
        :type job: Job
        :return: the job resource entity that nested dependencies are resolved
        :rtype: Job
        """
        self._append_tid_to_studio_url(job)
        self._resolve_job_inputs_arm_id(job)
        return self._resolve_arm_id_or_azureml_id(job, self._orchestrators.resolve_azureml_id)

    def _resolve_compute_id(self, resolver: Callable, target: Any) -> Any:
        # special case for local runs
        if target is not None and target.lower() == LOCAL_COMPUTE_TARGET:
            return LOCAL_COMPUTE_TARGET
        try:
            modified_target_name = target
            if target.lower().startswith(AzureMLResourceType.VIRTUALCLUSTER + "/"):
                # Compute target can be either workspace-scoped compute type,
                # or AML scoped VC. In the case of VC, resource name will be of form
                # azureml:virtualClusters/<name> to disambiguate from azureml:name (which is always compute)
                modified_target_name = modified_target_name[len(AzureMLResourceType.VIRTUALCLUSTER) + 1 :]
                modified_target_name = LEVEL_ONE_NAMED_RESOURCE_ID_FORMAT.format(
                    self._operation_scope.subscription_id,
                    self._operation_scope.resource_group_name,
                    AZUREML_RESOURCE_PROVIDER,
                    AzureMLResourceType.VIRTUALCLUSTER,
                    modified_target_name,
                )
            return resolver(
                modified_target_name,
                azureml_type=AzureMLResourceType.VIRTUALCLUSTER,
                sub_workspace_resource=False,
            )
        except Exception:
            return resolver(target, azureml_type=AzureMLResourceType.COMPUTE)

    def _resolve_job_inputs(self, entries: Iterable[Union[JobInput, str, bool, int, float]], base_path: str):
        """resolve job inputs as ARM id or remote url"""
        for entry in entries:
            self._resolve_job_input(entry, base_path)

    def _resolve_job_input(self, entry: Union[JobInput, str, bool, int, float], base_path: str) -> None:
        """resolve job input as ARM id or remote url"""
        if (
            not isinstance(entry, JobInput) or is_ARM_id_for_resource(entry.path) or is_url(entry.path)
        ):  # Literal value, ARM id or remote url. Pass through
            return

        try:
            if os.path.isabs(entry.path):  # absolute local path, upload, transform to remote url
                if entry.type == AssetTypes.URI_FOLDER and not os.path.isdir(entry.path):
                    raise Exception("There is no dir on target path: {}".format(entry.path))
                elif entry.type == AssetTypes.URI_FILE and not os.path.isfile(entry.path):
                    raise Exception("There is no file on target path: {}".format(entry.path))
                # absolute local path
                entry.path = _upload_and_generate_remote_uri(
                    self._operation_scope, self._orchestrators._datastore_operation, entry.path
                )
            elif ":" in entry.path or "@" in entry.path:  # Check for AzureML id, is there a better way?
                asset_type = AzureMLResourceType.DATASET
                if entry.type in [AssetTypes.MLFLOW_MODEL, AssetTypes.CUSTOM_MODEL]:
                    asset_type = AzureMLResourceType.MODEL

                entry.path = self._orchestrators.get_asset_arm_id(entry.path, asset_type)
            else:  # relative local path, upload, transform to remote url
                local_path = Path(base_path, entry.path).resolve()
                entry.path = _upload_and_generate_remote_uri(
                    self._operation_scope, self._orchestrators._datastore_operation, local_path
                )
        except Exception as e:
            raise Exception(f"Supported input path value are ARM id, AzureML id, remote uri or local path. {e}")

    def _resolve_job_inputs_arm_id(self, job: Job) -> None:
        try:
            inputs: Dict[str, Union[JobInput, str, bool, int, float]] = job.inputs
            for _, entry in inputs.items():
                if not isinstance(entry, JobInput) or is_url(entry.path):  # Literal value or remote url
                    continue
                else:  # ARM id
                    entry.path = self._orchestrators.resolve_azureml_id(entry.path)

        except AttributeError:
            # If the job object doesn't have "inputs" attribute, we don't need to resolve. E.g. AutoML jobs
            pass

    def _resolve_arm_id_or_azureml_id(self, job: Job, resolver: Callable) -> Job:
        """Resolve arm_id for a given job"""
        # TODO: this will need to be parallelized when multiple tasks
        # are required. Also consider the implications for dependencies.

        if isinstance(job, _BaseJob):
            job.compute = self._resolve_compute_id(resolver, job.compute)
        elif isinstance(job, CommandJob):
            job = self._resolve_arm_id_for_command_job(job, resolver)
        elif isinstance(job, SweepJob):
            job = self._resolve_arm_id_for_sweep_job(job, resolver)
        elif isinstance(job, AutoMLJob):
            job = self._resolve_arm_id_for_automl_job(job, resolver)
        elif isinstance(job, PipelineJob):
            job = self._resolve_arm_id_for_pipeline_job(job, resolver)
        else:
            raise Exception(f"Non supported job type: {type(job)}")
        return job

    def _resolve_arm_id_for_command_job(self, job: Job, resolver: Callable) -> Job:
        """Resolve arm_id for CommandJob"""
        if job.code is not None and not is_ARM_id_for_resource(job.code, AzureMLResourceType.CODE):
            job.code = resolver(Code(base_path=job._base_path, path=job.code), azureml_type=AzureMLResourceType.CODE)
        job.environment = resolver(job.environment, azureml_type=AzureMLResourceType.ENVIRONMENT)
        job.compute = self._resolve_compute_id(resolver, job.compute)
        return job

    def _resolve_arm_id_for_sweep_job(self, job: Job, resolver: Callable) -> Job:
        """Resolve arm_id for SweepJob"""
        if job.trial.code is not None and not is_ARM_id_for_resource(job.trial.code, AzureMLResourceType.CODE):
            job.trial.code = resolver(
                Code(base_path=job._base_path, path=job.trial.code), azureml_type=AzureMLResourceType.CODE
            )
        job.trial.environment = resolver(job.trial.environment, azureml_type=AzureMLResourceType.ENVIRONMENT)
        job.compute = self._resolve_compute_id(resolver, job.compute)
        return job

    def _resolve_arm_id_for_automl_job(self, job: Job, resolver: Callable) -> Job:
        """Resolve arm_id for AutoMLJob"""
        # AutoML does not have dependency uploads. Only need to resolve reference to arm id.
        job.compute = resolver(job.compute, azureml_type=AzureMLResourceType.COMPUTE)
        return job

    def _resolve_arm_id_for_pipeline_job(self, pipeline_job: "PipelineJob", resolver: Callable) -> Job:
        """Resolve arm_id for pipeline_job"""
        # validate before resolve arm ids
        pipeline_job._validate()

        # Get top-level job compute
        self._get_job_compute_id(pipeline_job, resolver)

        # Process job defaults:
        if pipeline_job.settings:
            pipeline_job.settings.default_datastore = resolver(
                pipeline_job.settings.default_datastore, azureml_type=AzureMLResourceType.DATASTORE
            )
            pipeline_job.settings.default_compute = resolver(
                pipeline_job.settings.default_compute, azureml_type=AzureMLResourceType.COMPUTE
            )

        # Process each component job
        if pipeline_job.jobs:

            for key, job_instance in pipeline_job.jobs.items():
                if not isinstance(job_instance, CommandComponent):
                    raise Exception(f"Non supported job type in Pipeline jobs: {type(job_instance)}")

                # Get the default for the specific job type
                if (
                    isinstance(job_instance.component, CommandComponentVersion)
                    and job_instance.component._is_anonymous
                    and not job_instance.component.display_name
                ):
                    job_instance.component.display_name = key

                # Get compute for each job
                self._get_job_compute_id(job_instance, resolver)

                # set default code & environment for component
                self._set_defaults_to_component(job_instance.component, pipeline_job.settings)

                # Get the component id for each job's component
                job_instance._component = resolver(job_instance.component, azureml_type=AzureMLResourceType.COMPONENT)

        return pipeline_job

    def _get_pipeline_component_job_dataset_ids(self, inputs: InputsAttrDict, resolver: Callable) -> None:
        """Processes dataset inputs for both PipelineJob and Component"""
        if inputs:
            for input_value in inputs.values():
                # Get the dataset ARM ID for any dataset inputs.
                # Since the backend calls the DataVersionService and not DatasetVersionService, replace "datasets" in ARM id with "data"
                if isinstance(input_value._data, JobInput) and input_value.dataset:
                    input_value._data.dataset = resolver(input_value.dataset, azureml_type=AzureMLResourceType.DATASET)

    def _get_job_compute_id(self, job: Union[Job, CommandComponent], resolver: Callable) -> None:
        job.compute = resolver(job.compute, azureml_type=AzureMLResourceType.COMPUTE)

    def _append_tid_to_studio_url(self, job: Job) -> None:
        """Appends the user's tenant ID to the end of the studio URL so the UI knows against which tenant to authenticate"""
        try:
            studio_endpoint = job.services.get("Studio", None)
            studio_url = studio_endpoint.endpoint
            # Extract the tenant id from the credential using PyJWT
            decode = jwt.decode(
                self._credential.get_token(*DEFAULT_SCOPES).token,
                options={"verify_signature": False, "verify_aud": False},
            )
            tid = decode["tid"]
            formatted_tid = TID_FMT.format(tid)
            studio_endpoint.endpoint = studio_url + formatted_tid
        except Exception:
            module_logger.info("Proceeding with no tenant id appended to studio URL\n")

    def _set_defaults_to_component(self, component: Union[str, ComponentVersion], settings: PipelineJobSettings):
        """Set default code&environment to component if not specified."""
        if isinstance(component, CommandComponentVersion):
            # TODO: do we have no place to set default code & environment?
            pass

    def _set_headers_with_user_aml_token(self, kwargs) -> Dict[str, str]:
        aml_token = self._credential.get_token(*AZUREML_SCOPES).token
        headers = kwargs.pop("headers", {})
        headers["x-azureml-token"] = aml_token
        kwargs["headers"] = headers
