# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azure.ml.version import VERSION

USER_AGENT = "{}/{}".format("azure-ml", VERSION)
