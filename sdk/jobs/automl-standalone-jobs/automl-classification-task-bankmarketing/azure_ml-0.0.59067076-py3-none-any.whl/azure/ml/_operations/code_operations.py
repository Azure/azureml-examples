# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Dict

from azure.ml._artifacts._artifact_utilities import _check_and_upload_path
from azure.ml._artifacts._constants import ASSET_PATH_ERROR, CHANGED_ASSET_PATH_MSG
from azure.ml._operations.datastore_operations import DatastoreOperations
from azure.ml._restclient.v2021_10_01 import AzureMachineLearningWorkspaces as ServiceClient102021
from azure.ml._dependent_operations import OperationScope, _DependentOperations
from azure.ml.entities._assets import Code

from azure.ml._telemetry import AML_INTERNAL_LOGGER_NAMESPACE, ActivityType, monitor_with_activity

logger = logging.getLogger(AML_INTERNAL_LOGGER_NAMESPACE + __name__)
logger.propagate = False
module_logger = logging.getLogger(__name__)


class CodeOperations(_DependentOperations):
    """Represents a client for performing operations on code assets

    You should not instantiate this class directly. Instead, you should create MLClient and
    use this client via the property MLClient.code
    """

    def __init__(
        self,
        operation_scope: OperationScope,
        service_client: ServiceClient102021,
        datastore_operations: DatastoreOperations,
        **kwargs: Dict,
    ):
        super(CodeOperations, self).__init__(operation_scope)
        if "app_insights_handler" in kwargs:
            logger.addHandler(kwargs.pop("app_insights_handler"))
        self._service_client = service_client
        self._version_operation = service_client.code_versions
        self._container_operation = service_client.code_containers
        self._datastore_operation = datastore_operations
        self._init_kwargs = kwargs

    @monitor_with_activity(logger, "Code.CreateOrUpdate", ActivityType.PUBLICAPI)
    def create_or_update(self, code: Code) -> Code:
        """Returns created or updated code asset.

        If not already in storage, asset will be uploaded to the workspace's default datastore.

        :param code: Code asset object.
        :type code: Code
        """
        name = code.name
        version = code.version

        code, _ = _check_and_upload_path(artifact=code, asset_operations=self)

        # For anonymous code, if the code already exists in storage, we reuse the name, version stored in the storage
        # metadata so the same anonymous code won't be created again.
        if code._is_anonymous:
            name = code.name
            version = code.version

        code_version_resource = code._to_rest_object()

        try:
            result = self._version_operation.create_or_update(
                name=name,
                version=version,
                workspace_name=self._workspace_name,
                resource_group_name=self._operation_scope.resource_group_name,
                body=code_version_resource,
                **self._init_kwargs,
            )
        except Exception as e:
            # service side raises an exception if we attempt to update an existing asset's asset path
            if str(e) == ASSET_PATH_ERROR:
                raise Exception(CHANGED_ASSET_PATH_MSG)
            else:
                raise e

        return Code._from_rest_object(result)

    @monitor_with_activity(logger, "Code.Get", ActivityType.PUBLICAPI)
    def get(self, name: str, version: str) -> Code:
        """Returns information about the specified code asset.

        :param name: Name of the code asset.
        :type name: str
        :param version: Version of the code asset.
        :type version: str
        """
        if not version:
            raise Exception("Code asset version must be specified as part of name parameter, in format 'name:version'.")
        else:
            code_version_resource = self._version_operation.get(
                name=name,
                version=version,
                resource_group_name=self._operation_scope.resource_group_name,
                workspace_name=self._workspace_name,
                **self._init_kwargs,
            )
            return Code._from_rest_object(code_version_resource)

    @monitor_with_activity(logger, "Code.Delete", ActivityType.PUBLICAPI)
    def delete(self, name: str, version: str) -> None:
        """Deletes a specified version of a code asset

        :param name: Name of code asset.
        :type name: str
        :param version: Version of the code asset.
        :type version: str
        """
        if version:
            return self._version_operation.delete(
                name=name, version=version, workspace_name=self._workspace_name, **self._scope_kwargs
            )
        else:
            raise Exception("Deletion on the whole lineage is not supported yet. " "Please specify a version.")
