# Loaders and helper functions for AzureMLFlow integration
## Loaders
Mlflow uses entry_points to automatically register loaders that follow a specification.
azureml-mlflow's setup.py points to the two registered loaders.

### azureml_store_builder for loading the AzureML tracking store
excerpt from setup.py: "mlflow.tracking_store": "azureml = azureml.mlflow:azureml_store_builder"

The above line registers the azureml_store_builder function as a loader of the mlflow.store.tracking.abstract_store.AbstractStore class.
The Azureml implementation implements an mlflow.store.tracking.rest_store.RestStore which is a rest implementation of the AbstractStore.
Most of the logic is service side with some auth and error handling client side.

### azureml_artifacts_builder for loading the AzureML artifact repository
Artifact repository loaders follow a similar spec related to entry_points for auto registration.
The returned class is expected to inherit from the mlflow.store.artifact.artifact_repository.ArtifactRepository class.
The current implementation uses azureml._restclient utils to implement a mostly auto generated client that,
uses the current store or artifact_uri for instantiation, and calls RunArtifacts routes for core functionality.


## Tracking uri
A helper function azureml.core.Workspace.get_mlflow_tracking_uri(with_auth=True) is monkeypatched onto the Workspace.
This helper funtion is used to initiate the integration.

Indented code

    // Steps for configuring the azure mlflow tracking store
    import mlflow
    from azureml.core import Workspace
    ws = Workspace.from_config()
    mlflow.set_tracking_uri(ws.get_mlflow_tracking_uri())

    // Required since azureml-mlflow does not support a default experiment.
    experiment_name = "readme_experiment"
    mlflow.set_experiment(experiment_name)

## Helper functions
Some convenience functions to expose azureml specific functionality with the mlflow Run entity

### Get the url for the Run in AzureML's Portal UI
Indented code
        from azureml.mlflow import get_portal_url

        with mlflow.start_run() as run:
            print(get_portal_url(run))  # Prints out a link to the run's metrics and artifacts in AzureML's portal UI.

### Register a model linked to the Run entity
Indented code
        from mlflow.sklearn import log_model
        with mlflow.start_run() as run:
            log_model(sklearn_model, "model_path")
            register_model(run, "sklearn_model", "model_path", tags={"my": "tags"})
