# How to generate proto files for aml_service specific contracts
1. Currently log_batch_async is experimental API and in mlflow is only exposed at abstract_store level.
2. So to enable async logging of metrics we need to implement this API at AzureMLRestStore level.
3. We need one more api to be exposed at AzureMLRestStore - get_run_data_status. This is to ensure we can track if certain data batch
   is persisted by the backend or not.
4. Since these APIs are not exposed at mlflow RestStore level we need to add those specific contracts in aml_service.proto file.
5. Below section describes how to generate the .py file for this proto file should any changes are required going forward to these contracts.
6. Note that both log_batch_async and get_run_data_status are both experimental APIs and only available in AzureMLRestStore level.

## Steps to modify aml_service.proto
1. Make following changes on WSL on windows or linux machine for smoother experience.
2. Ensure you are using the mlflow dev env as described here  - [mlflow-dev](https://github.com/mlflow/mlflow/blob/master/dev/dev-env-setup.sh)
3. Make any changes necessary to this file - _protos/aml_service.proto
4. Go to this and download following files - [Mlflow Protos](https://github.com/mlflow/mlflow/tree/master/mlflow/protos)
    1. service.proto
    2. databricks.proto
    3. scalapb.proto
5. Then copy the file to the protos folder with structure like this - ![Protos folder structure](how-to-arrange-protos.png)
6. Start docker on your machine. 
7. Activate mlflow-dev venv. Command example on wsl: source /mnt/c/work/amlrepos/mlflow/.venvs/mlflow-dev/bin/activate
8. Navigate to AzureMlCli/src/azureml-mlflow/azureml folder.
9. Run following commands one after another. Both these commands can be found in /dev/Dockerfile.protos comment section at top.
    1. `DOCKER_BUILDKIT=1 docker build -f mlflow/dev/Dockerfile.protos -t gen-protos .`
    2. `docker run --rm -w /app -v $(pwd):/app gen-protos python3 ./mlflow/dev/generate_protos.py`
        
        If you get error like google.protobuf not found, then run this command : `rm -rf .cache/protobuf_cache`

    3. Your console should something like this - ![generate-protos](dockerrun_img3.png)
10. Verify that aml_service_pb2.py is generated.
11. Comment the lines shown here in aml_service_pb2.py, to avoid import errors.: ![Comment lines](comment-imports-in-aml-service-pb2.png)
12. Test if the changes made are working appropriately.
13. Once satisfied that things are working correctly, now only stage aml_service.proto and aml_service_pb2.py files for commit and commit the changes.
14. Do not check in any of the other .proto or *_pb2.py files.