# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

class ClientEnvVars(object):
    AZUREML_HTTP_REQUEST_TIMEOUT = "AZUREML_HTTP_REQUEST_TIMEOUT"
    AZUREML_LOG_NETWORK_TRACES = "AZUREML_LOG_NETWORK_TRACES"
